package com.example.projetosofrimento;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CatOcorrencia extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cat_ocorrencia);
    }
}